﻿namespace MTCGServer.Models
{
    public enum ElementType
    {
        Fire,
        Water,
        Normal
    }
}
