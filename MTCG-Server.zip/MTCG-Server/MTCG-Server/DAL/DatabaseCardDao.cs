﻿using SWE1.MessageServer.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTCGServer.DAL
{
    internal class DatabaseCardDao : DatabaseDao, ICardDao
    {
        public DatabaseCardDao(string connectionString) : base(connectionString) { }

    }
}
