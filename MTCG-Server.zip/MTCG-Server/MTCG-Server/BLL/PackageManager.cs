﻿using MTCGServer.DAL;
using MTCGServer.Models;
using Npgsql;
using SWE1.MessageServer.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTCGServer.BLL
{
    internal class PackageManager : IPackageManager
    {
        private readonly IPackageDao _packageDao;
        public PackageManager(IPackageDao packageDao) 
        {
            _packageDao = packageDao;
        }
        public bool AddPackage(Package package)
        {
            try
            {
                return _packageDao.AddPackage(package);
            }
            catch (Exception ex)
            {
                if (ex is DataAccessFailedException)
                {
                    throw new DataAccessException();
                }
                if (ex is PostgresException)
                {
                    throw new DuplicateDataException();
                }
                else
                {
                    throw;
                }
            }
        }

        public List<Card>? BuyPackage(User user)
        {
            try 
            { 
                return _packageDao.BuyPackage(user);
            }
            catch (Exception ex)
            {
                if (ex is DataAccessFailedException)
                {
                    throw new DataAccessException();
                }
                else if (ex is NotEnoughMoneyException)
                {
                    throw new TooLessMoneyException();
                }
                else
                {
                    throw;
                }
            }
        }
    }
}
