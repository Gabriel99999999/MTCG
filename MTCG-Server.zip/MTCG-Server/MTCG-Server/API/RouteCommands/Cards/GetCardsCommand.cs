﻿using MTCGServer.API.RouteCommands.Packages;
using MTCGServer.BLL;
using MTCGServer.Core.Response;
using MTCGServer.Core.Routing;
using MTCGServer.Models;


namespace MTCGServer.API.RouteCommands.Cards
{
    internal class GetCardsCommand : ICommand
    {
        private ICardManager _cardManager;
        private User _user;

        public GetCardsCommand(ICardManager cardManager, User user)
        {
            _cardManager = cardManager;
            _user = user;
        }

        public Response Execute()
        {
            throw new NotImplementedException();
        }
    }
}