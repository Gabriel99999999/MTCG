﻿namespace MTCGServer.Core.Server
{
    public interface IServer
    {
        void Start();
        void Stop();
    }
}
